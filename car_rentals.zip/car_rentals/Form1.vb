﻿Public Class Form1

    Private Sub lblTitle_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cboVehicleType.Items.Add("Sedan")
        cboVehicleType.Items.Add("SUV")
        cboVehicleType.Items.Add("Truck")

        cboVehicleType.SelectedIndex = -1

        txtDays.Clear()
        txtDailyCharge.Clear()
        txtTotalCost.Clear()

    End Sub

    Private Sub cboVehicleType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboVehicleType.SelectedIndexChanged

        If cboVehicleType.Text = "Sedan" Then
            txtDailyCharge.Text = "150000"

        ElseIf cboVehicleType.Text = "SUV" Then
            txtDailyCharge.Text = "290000"

        ElseIf cboVehicleType.Text = "Truck" Then
            txtDailyCharge.Text = "350000"

        Else
            txtDailyCharge.Clear()
        End If

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click


        Dim dailyCharge As Decimal
        Dim daysRented As Integer
        Dim totalCost As Decimal

        If cboVehicleType.SelectedIndex = -1 Then
            MessageBox.Show("Please select a vehicle type.")
            Exit Sub
        End If

        If Not Integer.TryParse(txtDays.Text, daysRented) Then
            MessageBox.Show("Please enter a valid number of days.")
            txtDays.Focus()
            Exit Sub
        End If

        If daysRented <= 0 Then
            MessageBox.Show("Rental days must be greater than zero.")
            txtDays.Focus()
            Exit Sub
        End If

        dailyCharge = Decimal.Parse(txtDailyCharge.Text)

        totalCost = dailyCharge * daysRented

        txtTotalCost.Text = totalCost.ToString("N0")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        cboVehicleType.SelectedIndex = -1
        txtDays.Clear()
        txtDailyCharge.Clear()
        txtTotalCost.Clear()

        txtDays.Focus()

    End Sub

End Class
